<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use Illuminate\Http\JsonResponse;

class ExampleTest extends TestCase
{
    /**
     * A basic test example.
     *
     * @return void
     */
    public function test_showBankList()
    {
        $response = $this->json('GET', '/api/index', [
            'api_type' => 'banklist',
        ]);
        $response->assertStatus(200);
    }

    // public function test_create_account()
    // {
    //     $response = $this->json('POST', '/api/account/create', [
    //         'api_type' => 'createaccount',
    //         'bankId'=>'1',
    //         'accountTypeId'=>'2',
    //         'accountSubTypeId'=>'1',
    //         'ownerName'=>"udaykirantest",
    //         'mobile'=>'9000567565',
    //         'address'=>'hyd'
    //     ]);

    //     $response->assertStatus(200);
    // }

    public function test_show_account_list()
    {
        $response = $this->json('GET', '/api/account/', [
            'api_type' => 'accountowner',
            'bank_id' => '1',
        ]);
        $response->assertStatus(200);
    }

    public function test_single_account_data()
    {
        $response = $this->json('GET', '/api/account/1', [
            'api_type' => 'accountdetails',
            'accountNumber' => '5010085848',
        ]);
        $response->assertStatus(200);
    }

    public function test_remove_account()
    {
        $response = $this->json('POST', '/api/account/remove/3', [
            'api_type' => 'removeAccount',
        ]);
        $response->assertStatus(200);
    }

    public function test_account_deposit()
    {
        $response = $this->json('POST', '/api/account/deposit/', [
            'api_type' => 'banktransaction',
            'bank_id' => '1',
            'ownerId' => '1',
            'transactionType' => '1',
            'amount' => '120.05',
            'tarnsactionMode' => 'CASH',
        ]);
        $response->assertStatus(200);
    }

    public function test_update_account()
    {
        $response = $this->json('POST', '/api/account/modify/1', [
            'api_type' => 'updateaccount',
            'bank_id' => '1',
            'bankAccountTypeId' => '2',
            'bankSubAccountTypeId' => '2',
            'owenName' => 'uday',
            'mobile' => '9000749151',
            'address' => 'Hyd near bagayalatha bagayalatha 508356',
        ]);
        $response->assertStatus(200);
    }

    public function test_account_withdrawal()
    {
        $response = $this->json('POST', '/api/account/withdrawal/', [
            'api_type' => 'banktransaction',
            'bank_id' => '1',
            'ownerId' => '1',
            'account_no' => '5010093987',
            'transactionType' => '2',
            'tarnsactionMode' => 'CASH',
            'amount' => '100',
        ]);
        $response->assertStatus(200);
    }

    public function test_transferAmount()
    {
        $response = $this->json('POST', '/api/account/transferAmount/', [
            'api_type' => 'balancetransfer',
            'bank_id' => '1',
            'ownerId' => '1',
            'account_no' => '5010085848',
            'transactionType' => '3',
            'tarnsactionMode' => 'NEFT',
            'amount' => '40',
            'tobankid'=>'1',
            'toOwnerid'=>'2',
            'toaccountno'=>"5010058898"
        ]);

        $response->assertStatus(200);
    }

}
