<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Exception;
use Illuminate\Contracts\Validation\Validator;

class AccountController extends Controller
{
    public function __construct()
    {
        $this->accountPath = public_path() . '/json/Account.json';
        $accountsData = [];
        $this->accountsData = json_decode(
            file_get_contents($this->accountPath),
            true
        );

        $bankPath = public_path() . '/json/Bank.json';
        $this->banks = json_decode(file_get_contents($bankPath), true);

        $accountTypePath = public_path() . '/json/AccoutTypes.json';
        $this->accountTypes = json_decode(
            file_get_contents($accountTypePath),
            true
        );

        $SubAccountTypePath = public_path() . '/json/SubAccountTypes.json';
        $this->subAccountTypes = json_decode(
            file_get_contents($SubAccountTypePath),
            true
        );

        $this->transactionsPath = public_path() . '/json/Transactions.json';
        $this->transactionsData = json_decode(
            file_get_contents($this->transactionsPath),
            true
        );
    }
    /* show bank account list */
    public function index(Request $request)
    {
        try {
            if (
                $request->input('api_type') &&
                $request->input('api_type') == 'accountowner'
            ) {
                $validations = $this->validate($request, [
                    'bank_id' => 'required',
                ]);

                if (isset($request->bank_id) && !empty($request->bank_id)) {
                    $reqBankId = $request->input('bank_id');
                    $path = public_path() . '/json/Account.json';
                    $accountsData = [];
                    $accountsData = json_decode(file_get_contents($path), true);
                    $accountList = [];
                    foreach ($accountsData as $accounts) {
                        if (in_array($reqBankId, $accounts)) {
                            if (
                                $reqBankId == $accounts['bank_id'] &&
                                $accounts['account_status'] == 'Active'
                            ) {
                                if (in_array($reqBankId, $accounts)) {
                                    $accountList[] = $accounts;
                                }
                            }
                        }
                    }

                    $result = [];
                    $allAccounts = [];
                    foreach ($accountList as $key => $account_data) {
                        $banks = $this->banks;
                        $bank_data = [];

                        foreach ($banks as $key => $bank) {
                            if (in_array($request['bank_id'], $bank)) {
                                $bank_data['bank_name'] = $bank['bank_name'];
                            }
                        }
                        $accountTypes = $this->accountTypes;
                        $subAccountTypes = $this->subAccountTypes;
                        $account_type = [];
                        foreach ($accountTypes as $key => $accountType) {
                            if (
                                in_array(
                                    $account_data['account_type_id'],
                                    $accountType
                                )
                            ) {
                                $account_type['type'] = $accountType['type'];
                            }
                        }
                        $subAccount_type = [];
                        foreach ($subAccountTypes as $key => $subAccountType) {
                            if (
                                in_array(
                                    $account_data['account_sub_type_id'],
                                    $subAccountType
                                )
                            ) {
                                if (
                                    $subAccountType['id'] ==
                                    $account_data['account_sub_type_id']
                                ) {
                                    $subAccount_type['account_sub_type'] =
                                        $subAccountType['account_sub_type'];
                                }
                            }
                        }

                        $result['bankId'] = $account_data['bank_id'];
                        $result['bank_name'] = $bank_data['bank_name'];
                        $result['accountTypeId'] =
                            $account_data['account_type_id'];
                        $result['account_Type'] = $account_type['type'];

                        if ($account_data['account_sub_type_id'] != '') {
                            $result['subAccountTypeId'] =
                                $account_data['account_sub_type_id'];
                        } else {
                            $result['subAccountTypeId'] = 'null';
                        }
                        if ($subAccount_type) {
                            $result['account_sub_type'] =
                                $subAccount_type['account_sub_type'];
                        } else {
                            $result['account_sub_type'] = 'null';
                        }
                        $result['accountOwnerId'] = $account_data['id'];
                        $result['account_no'] = $account_data['account_number'];
                        $result['account_name'] =
                            $account_data['account_owner_name'];
                        $result['available balance'] =
                            $account_data['account_balance'];
                        $result['mobile'] = $account_data['mobile'];
                        $result['address'] = $account_data['address'];
                        $result['accountStatus'] =
                            $account_data['account_status'];

                        $allAccounts[] = $result;
                    }
                    return response()->json([
                        'status' => 'success',
                        'data' => $allAccounts,
                        'message' => 'Bank Account Owner List',
                    ]);
                } else {
                    throw new Exception('Please Provide bank_id');
                }
            } else {
                throw new Exception('API type invalied');
            }
        } catch (\Exception $e) {
            return response()
                ->json(['status' => 'failed', 'message' => $e->getMessage()])
                ->setStatusCode(500);
        }
    }

    /* create new account */
    public function CreateAccount(Request $request)
    {
        try {
            if (
                $request->input('api_type') &&
                $request->input('api_type') == 'createaccount'
            ) {
                $validations = $this->validate($request, [
                    'api_type' => 'required',
                    'bankId' => 'required',
                    'accountTypeId' => 'required',
                    'accountSubTypeId' => 'required',
                    'ownerName' => 'required',
                    'mobile' => 'required',
                    'address' => 'required',
                ]);

                $acountNumberStart = 50100;
                $randumNumber = rand(10000, 99999);
                $acountNumber = $acountNumberStart . '' . $randumNumber;
                $balance = 0;
                $balance = sprintf('%01.2f', $balance);
                $accountsData = [];
                $accountsData = $this->accountsData;
                if (!empty($accountsData)) {
                    foreach ($accountsData as $accountData) {
                        if (in_array($request['ownerName'], $accountData)) {
                            throw new Exception(
                                'This account name already exits'
                            );
                        }
                        if (in_array($acountNumber, $accountData)) {
                            throw new Exception('Account Number already exits');
                        }
                        if (in_array($request['mobile'], $accountData)) {
                            throw new Exception('Mobile Number already exits');
                        }
                    }
                }

                $reqData = [];
                if (!empty($accountsData)) {
                    if (count($accountsData) > 0) {
                        $last_list = end($accountsData);
                        $id = $last_list['id'] + 1;
                        $reqData['id'] = $id;
                    } else {
                        $reqData['id'] = '1';
                    }
                } else {
                    $reqData['id'] = '1';
                    $accountsData = [];
                }
                if ($request['accountSubTypeId'] != '') {
                    $accountSubTypeId = $request['accountSubTypeId'];
                } else {
                    $accountSubTypeId = 'Null';
                }
                $reqData['bank_id'] = $request['bankId'];
                $reqData['account_number'] = $acountNumber;
                $reqData['account_type_id'] = $request['accountTypeId'];
                $reqData['account_sub_type_id'] = $accountSubTypeId;
                $reqData['account_owner_name'] = $request['ownerName'];
                $reqData['account_balance'] = $balance;
                $reqData['mobile'] = $request['mobile'];
                $reqData['address'] = $request['address'];
                $reqData['account_status'] = 'Active';

                array_push($accountsData, $reqData);

                $jsonData = json_encode($accountsData);
                file_put_contents($this->accountPath, $jsonData);

                $bank_data = [];
                $banks = $this->banks;
                foreach ($banks as $key => $bank) {
                    if (in_array($request['bankId'], $bank)) {
                        $bank_data['bank_name'] = $bank['bank_name'];
                    }
                }
                $accountTypes = $this->accountTypes;
                $account_type = [];
                foreach ($accountTypes as $key => $accountType) {
                    if (in_array($request['accountTypeId'], $accountType)) {
                        $account_type['type'] = $accountType['type'];
                    }
                }
                $subAccountTypes = $this->subAccountTypes;
                $subAccount_type = [];

                if ($request['accountSubTypeId'] == '') {
                    $subAccount_type['account_sub_type'] = 'Null';
                } else {
                    foreach ($subAccountTypes as $key => $subAccountType) {
                        if (
                            in_array(
                                $request['accountSubTypeId'],
                                $subAccountType
                            )
                        ) {
                            if (
                                $subAccountType['id'] ==
                                $request['accountSubTypeId']
                            ) {
                                $subAccount_type['account_sub_type'] =
                                    $subAccountType['account_sub_type'];
                            }
                        }
                    }
                }

                $result['bankID'] = $reqData['bank_id'];
                $result['bank_name'] = $bank_data['bank_name'];
                $result['accountTypeId'] = $reqData['account_type_id'];
                $result['accountType'] = $account_type['type'];
                $result['accountSubTypeId'] = $reqData['account_sub_type_id'];
                $result['account_sub_type'] =
                    $subAccount_type['account_sub_type'];

                $result['account_number'] = $acountNumber;
                $result['owner_name'] = $reqData['account_owner_name'];
                $result['mobile'] = $reqData['mobile'];
                $result['address'] = $reqData['address'];
                $result['accountStatus'] = $reqData['account_status'];

                return response()->json([
                    'status' => 'success',
                    'data' => $result,
                    'message' => 'Account created successfully.',
                ]);
            } else {
                throw new Exception('API type invalied');
            }
        } catch (\Exception $e) {
            return response()
                ->json(['status' => 'failed', 'message' => $e->getMessage()])
                ->setStatusCode(500);
        }
    }

    /* Get accountDetails using owner id and account number */

    public function accountDetails(Request $request, $id)
    {
        try {
            $owenerId = $id;
            if (
                $request->input('api_type') &&
                $request->input('api_type') != 'accountdetails'
            ) {
                throw new Exception('API type invalied');
            }
            $validations = $this->validate($request, [
                'accountNumber' => 'required',
            ]);
            if (
                isset($request->accountNumber) &&
                !empty($request->accountNumber)
            ) {
                $accountNumber = $request->accountNumber;
                $accounts = $this->accountsData;
                $account_data = [];

                foreach ($accounts as $key => $account) {
                    if (
                        $account['account_number'] == $accountNumber &&
                        $account['id'] == $owenerId &&
                        $account['account_status'] == 'Active'
                    ) {
                        $account_data = $account;
                    }
                }

                if ($account_data) {
                    $banks = $this->banks;
                    $bank_data = [];
                    foreach ($banks as $key => $bank) {
                        if (in_array($account_data['bank_id'], $bank)) {
                            $bank_data['bank_name'] = $bank['bank_name'];
                        }
                    }

                    $accountTypes = $this->accountTypes;
                    $account_type = [];
                    foreach ($accountTypes as $key => $accountType) {
                        if (
                            in_array(
                                $account_data['account_type_id'],
                                $accountType
                            )
                        ) {
                            $account_type['type'] = $accountType['type'];
                        }
                    }
                    $subAccountTypes = $this->subAccountTypes;
                    $subAccount_type = [];
                    foreach ($subAccountTypes as $key => $subAccountType) {
                        if (
                            in_array(
                                $account_data['account_sub_type_id'],
                                $subAccountType
                            )
                        ) {
                            if (
                                $subAccountType['id'] ==
                                $account_data['account_sub_type_id']
                            ) {
                                $subAccount_type['account_sub_type'] =
                                    $subAccountType['account_sub_type'];
                            }
                        }
                    }
                    $result['bankId'] = $account_data['bank_id'];
                    $result['bank_name'] = $bank_data['bank_name'];
                    $result['accountTypeId'] = $account_data['account_type_id'];
                    $result['accountType'] = $account_type['type'];
                    $result['subAccountTypeId'] =
                        $account_data['account_sub_type_id'];
                    $result['subAccountType'] =
                        $subAccount_type['account_sub_type'];
                    $result['accountOwnerID'] = $account_data['id'];
                    $result['account_no'] = $account_data['account_number'];
                    $result['ownerName'] = $account_data['account_owner_name'];
                    $result['accountBalance'] =
                        $account_data['account_balance'];

                    $result['mobile'] = $account_data['mobile'];
                    $result['address'] = $account_data['address'];
                    $result['accountStatus'] = $account_data['account_status'];
                    return response()->json([
                        'status' => 'success',
                        'data' => $result,
                        'message' => 'Bank account owner details.',
                    ]);
                } else {
                    return response()->json([
                        'status' => 'success',
                        'data' => $account_data,
                        'message' => 'Bank account owner details.',
                    ]);
                }
            } else {
                throw new Exception('Please Provide Account Number');
            }
            $accountNumber = $request->accountNumber;
        } catch (\Exception $e) {
            return response()
                ->json(['status' => 'failed', 'message' => $e->getMessage()])
                ->setStatusCode(500);
        }
    }

    /* user Account soft deleted */

    public function removeAccount(Request $request)
    {
        try {
            $validations = $this->validate($request, [
                'api_type' => 'required',
                'owner_id' => 'required',
            ]);
            if (
                isset($request->api_type) &&
                $request->api_type == 'removeAccount'
            ) {
                $accountsData = $this->accountsData;
                $owner_id = $request->input('owner_id');
                foreach ($accountsData as $key => $accounts) {
                    if ($owner_id == $accounts['id']) {
                        $accountsData[$key]['account_status'] = 'InActive';
                    }
                }
                $jsonData = json_encode($accountsData);
                file_put_contents($this->accountPath, $jsonData);
                return response()->json([
                    'status' => 'success',
                    'data' => [],
                    'message' => 'Owner account has been removed',
                ]);
            } else {
                throw new Exception('API type is invalied');
            }
        } catch (\Exception $e) {
            return response()
                ->json(['status' => 'failed', 'message' => $e->getMessage()])
                ->setStatusCode(500);
        }
    }

    /* User add money to his account */

    public function addMoney(Request $request)
    {
        try {
            if (
                isset($request->api_type) &&
                $request->api_type == 'banktransaction'
            ) {
                $validations = $this->validate($request, [
                    'bank_id' => 'required',
                    'ownerId' => 'required',
                    'transactionType' => 'required',
                    'amount' => 'required',
                    'tarnsactionMode' => 'required',
                ]);

                $bankId = $request->input('bank_id');
                $ownerID = $request->input('ownerId');
                $transactionType = $request->input('transactionType');
                $amount = $request->input('amount');
                $accountsData = $this->accountsData;

                $owenerAccount = [];
                if ($transactionType != 1) {
                    throw new Exception('Transaction type invalied');
                }
                if (!empty($accountsData)) {
                    foreach ($accountsData as $key => $account) {
                        if (
                            $ownerID == $account['id'] &&
                            $bankId == $account['bank_id'] &&
                            $account['account_status'] == 'Active'
                        ) {
                            $owenerAccount['account_balance'] =
                                $account['account_balance'];
                        }
                    }
                } else {
                    return response()->json([
                        'status' => 'failed',
                        'data' => [],
                        'message' => 'There is no account.',
                    ]);
                }
                if (!empty($owenerAccount)) {
                    $available_balance = $owenerAccount['account_balance'];
                    $tatalAmount = $available_balance + $amount;
                } else {
                    return response()->json([
                        'status' => 'failed',
                        'data' => [],
                        'message' =>
                            'There is no account for this ownerId and bankID,',
                    ]);
                }

                $tatalAmount = sprintf('%01.2f', $tatalAmount);
                foreach ($accountsData as $key => $account) {
                    if (
                        $ownerID == $account['id'] &&
                        $bankId == $account['bank_id']
                    ) {
                        $accountsData[$key]['account_balance'] = $tatalAmount;
                    }
                }
                $transaction_Data = [];
                $transaction_Data = $this->transactionsData;
                $transactionData = [];
                if (!empty($transaction_Data)) {
                    if (count($transaction_Data) > 0) {
                        $last_list = end($transaction_Data);
                        $id = $last_list['id'] + 1;
                        $transactionData['id'] = $id;
                    } else {
                        $transactionData['id'] = '1';
                    }
                } else {
                    $transactionData['id'] = '1';
                    $transaction_Data = [];
                }

                $transactionData['bank_id'] = $bankId;
                $transactionData['sender_owener_id'] = $ownerID;
                $transactionData['transaction_type_id'] = $transactionType;
                $transactionData['transaction_mode'] = $request->input(
                    'tarnsactionMode'
                );
                $transactionData['transaction_amount'] = $amount;

                array_push($transaction_Data, $transactionData);

                $accousData = json_encode($accountsData);
                file_put_contents($this->accountPath, $accousData);

                $transActionData = json_encode($transaction_Data);

                file_put_contents($this->transactionsPath, $transActionData);

                return response()->json([
                    'status' => 'success',
                    'data' => [],
                    'message' => 'Amount Deposited successfully.',
                ]);
            } else {
                throw new Exception('API type is invalied');
            }
        } catch (\Exception $e) {
            return response()
                ->json(['status' => 'failed', 'message' => $e->getMessage()])
                ->setStatusCode(500);
        }
    }

    /* User Account update */

    public function updateAccount(Request $request, $id)
    {
        try {
            $account_data = $this->accountsData;
            $validations = $this->validate($request, [
                'bank_id' => 'required',
                'bankAccountTypeId' => 'required',
                'bankSubAccountTypeId' => 'required',
                'owenName' => 'required',
                'mobile' => 'required',
                'address' => 'required',
            ]);
            $bankId = $request->input('bank_id');

            $reqData = [];
            $reqData['account_type_id'] = $request->input('bankAccountTypeId');
            $reqData['account_sub_type_id'] = $request->input(
                'bankSubAccountTypeId'
            );
            $reqData['account_owner_name'] = $request->input('owenName');
            $reqData['mobile'] = $request->input('mobile');
            $reqData['address'] = $request->input('address');

            $account_list = [];

            foreach ($account_data as $key => $accounts) {
                if (
                    $bankId == $accounts['bank_id'] &&
                    $id == $accounts['id'] &&
                    $accounts['account_status'] == 'Active'
                ) {
                    $account_data[$key]['account_type_id'] =
                        $reqData['account_type_id'];
                    $account_data[$key]['account_sub_type_id'] =
                        $reqData['account_sub_type_id'];
                    $account_data[$key]['account_owner_name'] =
                        $reqData['account_owner_name'];
                    $account_data[$key]['mobile'] = $reqData['mobile'];
                    $account_data[$key]['address'] = $reqData['address'];
                    $account_list = $account_data[$key];
                }
            }

            if (!empty($account_list) > 0) {
                $account_data = json_encode($account_data);
                file_put_contents($this->accountPath, $account_data);

                $banks = $this->banks;
                $bank_data = [];

                foreach ($banks as $key => $bank) {
                    if (in_array($account_list['bank_id'], $bank)) {
                        $bank_data['bank_name'] = $bank['bank_name'];
                    }
                }
                $accountTypes = $this->accountTypes;
                $subAccountTypes = $this->subAccountTypes;
                $account_type = [];
                foreach ($accountTypes as $key => $accountType) {
                    if (
                        in_array($account_list['account_type_id'], $accountType)
                    ) {
                        $account_type['type'] = $accountType['type'];
                    }
                }
                $subAccount_type = [];
                foreach ($subAccountTypes as $key => $subAccountType) {
                    if (
                        in_array(
                            $account_list['account_sub_type_id'],
                            $subAccountType
                        )
                    ) {
                        if (
                            $subAccountType['id'] ==
                            $account_list['account_sub_type_id']
                        ) {
                            $subAccount_type['account_sub_type'] =
                                $subAccountType['account_sub_type'];
                        }
                    }
                }
                $result = [];

                $result['bankID'] = $account_list['bank_id'];
                $result['bank_name'] = $bank_data['bank_name'];
                $result['accountTypeId'] = $account_list['account_type_id'];
                $result['accountType'] = $account_type['type'];
                $result['subAccountTypeId'] =
                    $account_list['account_sub_type_id'];
                $result['subAccountType'] =
                    $subAccount_type['account_sub_type'];
                $result['accountOwenrId'] = $account_list['id'];
                $result['accountOwenName'] =
                    $account_list['account_owner_name'];
                $result['account_no'] = $account_list['account_number'];
                $result['availableBalance'] = $account_list['account_balance'];
                $result['mobile'] = $account_list['mobile'];
                $result['address'] = $account_list['address'];
                $result['accountStatus'] = $account_list['account_status'];

                return response()->json([
                    'status' => 'success',
                    'data' => $result,
                    'message' => 'Account Updated Successfully.',
                ]);
                // }
            } else {
                throw new Exception('This account owner id not exits');
            }
        } catch (\Exception $e) {
            return response()
                ->json(['status' => 'failed', 'message' => $e->getMessage()])
                ->setStatusCode(500);
        }
    }

    /* Money withdrawal Account user */

    public function withdrawalAmount(Request $request)
    {
        try {
            if (
                isset($request->api_type) &&
                $request->api_type == 'banktransaction'
            ) {
                $validations = $this->validate($request, [
                    'bank_id' => 'required',
                    'ownerId' => 'required',
                    'account_no' => 'required',
                    'transactionType' => 'required',
                    'tarnsactionMode' => 'required',
                    'amount' => 'required',
                ]);
                $bankId = $request->bank_id;
                $ownerID = $request->ownerId;
                $amount = $request->amount;
                $transactionType = $request->transactionType;
                $tarnsactionMode = $request->tarnsactionMode;
                $account_no = $request->account_no;
                $accountsData = $this->accountsData;

                $owenerAccount = [];
                if ($transactionType != 2) {
                    throw new Exception('Transaction type invalied');
                }
                if (!empty($accountsData)) {
                    foreach ($accountsData as $key => $account) {
                        if (
                            $ownerID == $account['id'] &&
                            $bankId == $account['bank_id'] &&
                            $account['account_status'] == 'Active'
                        ) {
                            $owenerAccount['account_balance'] =
                                $account['account_balance'];
                            $owenerAccount['account_sub_type_id'] =
                                $account['account_sub_type_id'];
                        }
                    }
                } else {
                    return response()->json([
                        'status' => 'failed',
                        'data' => [],
                        'message' => 'There is no account.',
                    ]);
                }

                if (!empty($owenerAccount)) {
                    $available_balance = $owenerAccount['account_balance'];
                    $totalAmount = $available_balance - $amount;
                } else {
                    return response()->json([
                        'status' => 'failed',
                        'data' => [],
                        'message' =>
                            'There is no account for this ownerId and bankID.',
                    ]);
                }
                $totalAmount = sprintf('%01.2f', $totalAmount);
                $subAccountTypes = $this->subAccountTypes;
                $subAccount_type = [];
                foreach ($subAccountTypes as $key => $subAccountType) {
                    if (
                        in_array(
                            $owenerAccount['account_sub_type_id'],
                            $subAccountType
                        )
                    ) {
                        if (
                            $subAccountType['id'] ==
                            $owenerAccount['account_sub_type_id']
                        ) {
                            $subAccount_type['account_sub_type'] =
                                $subAccountType['account_sub_type'];
                        }
                    }
                }

                if ($available_balance < $amount) {
                    throw new Exception('You have insufficient balance');
                } elseif (
                    $subAccount_type['account_sub_type'] == 'individual' &&
                    $amount > 500
                ) {
                    throw new Exception(
                        'Individual accounts have a withdrawal limits of 500 dollers'
                    );
                } else {
                    foreach ($accountsData as $key => $account) {
                        if (
                            $ownerID == $account['id'] &&
                            $bankId == $account['bank_id']
                        ) {
                            $accountsData[$key][
                                'account_balance'
                            ] = $totalAmount;
                        }
                    }

                    $accousData = json_encode($accountsData);
                    file_put_contents($this->accountPath, $accousData);
                    $transaction_Data = [];
                    $transaction_Data = $this->transactionsData;
                    if (!empty($transaction_Data)) {
                        if (count($transaction_Data) > 0) {
                            $last_list = end($transaction_Data);
                            $id = $last_list['id'] + 1;
                            $transactionData['id'] = $id;
                        } else {
                            $transactionData['id'] = '1';
                        }
                    } else {
                        $transactionData['id'] = '1';
                        $transaction_Data = [];
                    }

                    $transactionData['bank_id'] = $bankId;
                    $transactionData['sender_owener_id'] = $ownerID;
                    $transactionData['transaction_type_id'] = $transactionType;
                    $transactionData['transaction_mode'] = $tarnsactionMode;
                    $transactionData['transaction_amount'] = $amount;
                    array_push($transaction_Data, $transactionData);
                    $transActionData = json_encode($transaction_Data);
                    file_put_contents(
                        $this->transactionsPath,
                        $transActionData
                    );

                    return response()->json([
                        'status' => 'success',
                        'data' => [],
                        'message' => 'Amount withdrawal successfully.',
                    ]);
                }
            } else {
                throw new Exception('API type is invalied');
            }
        } catch (\Exception $e) {
            return response()
                ->json(['status' => 'failed', 'message' => $e->getMessage()])
                ->setStatusCode(500);
        }
    }

    /* Transfer ammount one user to anther user */
    public function transferAmount(Request $request)
    {
        try {
            if (
                isset($request->api_type) &&
                $request->api_type == 'balancetransfer'
            ) {
                $validations = $this->validate($request, [
                    'bank_id' => 'required',
                    'ownerId' => 'required',
                    'account_no' => 'required',
                    'transactionType' => 'required',
                    'tarnsactionMode' => 'required',
                    'amount' => 'required',
                    'tobankid' => 'required',
                    'toOwnerid' => 'required',
                    'toaccountno' => 'required',
                ]);

                $bankId = $request->bank_id;
                $ownerID = $request->ownerId;
                $amount = $request->amount;
                $transactionType = $request->transactionType;
                $tarnsactionMode = $request->tarnsactionMode;
                $account_no = $request->account_no;
                $tobankid = $request->tobankid;
                $toOwnerid = $request->toOwnerid;
                $toaAcountNo = $request->toaccountno;
                $accountsData = $this->accountsData;

                $fromAccount = [];
                $toAccount = [];
                if ($transactionType != 3) {
                    throw new Exception('Transaction type invalied');
                }
                if (!empty($accountsData)) {
                    foreach ($accountsData as $key => $account) {
                        if (
                            $ownerID == $account['id'] &&
                            $bankId == $account['bank_id'] &&
                            $account['account_status'] == 'Active'
                        ) {
                            $fromAccount['account_balance'] =
                                $account['account_balance'];
                            $fromAccount['account_sub_type_id'] =
                                $account['account_sub_type_id'];
                        }

                        if (
                            $toOwnerid == $account['id'] &&
                            $tobankid == $account['bank_id'] &&
                            $account['account_status'] == 'Active'
                        ) {
                            $toAccount['account_balance'] =
                                $account['account_balance'];
                            $toAccount['account_sub_type_id'] =
                                $account['account_sub_type_id'];
                        }
                    }
                } else {
                    return response()->json([
                        'status' => 'failed',
                        'data' => [],
                        'message' => 'There is no account.',
                    ]);
                }

                if (empty($fromAccount)) {
                    throw new Exception(
                        'From account not exits or not activated.'
                    );
                }
                if (empty($toAccount)) {
                    throw new Exception(
                        'To account not exits or not activated'
                    );
                }

                if ($fromAccount['account_balance'] < $amount) {
                    throw new Exception('You have insufficient balance');
                } else {
                    $fromAccountTotal =
                        $fromAccount['account_balance'] - $amount;
                    $toAccountTotal = $toAccount['account_balance'] + $amount;
                    $fromAccountTotal = sprintf('%01.2f', $fromAccountTotal);
                    $toAccountTotal = sprintf('%01.2f', $toAccountTotal);
                    foreach ($accountsData as $key => $account) {
                        if (
                            $ownerID == $account['id'] &&
                            $bankId == $account['bank_id']
                        ) {
                            $accountsData[$key][
                                'account_balance'
                            ] = $fromAccountTotal;
                        }

                        if (
                            $toOwnerid == $account['id'] &&
                            $tobankid == $account['bank_id']
                        ) {
                            $accountsData[$key][
                                'account_balance'
                            ] = $toAccountTotal;
                        }
                    }

                    $accousData = json_encode($accountsData);
                    file_put_contents($this->accountPath, $accousData);

                    $transaction_Data = [];
                    $transaction_Data = $this->transactionsData;
                    $transactionData = [];
                    if (!empty($transaction_Data)) {
                        if (count($transaction_Data) > 0) {
                            $last_list = end($transaction_Data);
                            $id = $last_list['id'] + 1;
                            $transactionData['id'] = $id;
                        } else {
                            $transactionData['id'] = '1';
                        }
                    } else {
                        $transactionData['id'] = '1';
                        $transaction_Data = [];
                    }

                    $transactionData['bank_id'] = $bankId;
                    $transactionData['sender_owener_id'] = $ownerID;
                    $transactionData['transaction_type_id'] = $transactionType;
                    $transactionData['transaction_mode'] = $tarnsactionMode;
                    $transactionData['transaction_amount'] = $amount;
                    array_push($transaction_Data, $transactionData);
                    $transActionData = json_encode($transaction_Data);
                    file_put_contents(
                        $this->transactionsPath,
                        $transActionData
                    );
                    return response()->json([
                        'status' => 'success',
                        'data' => [],
                        'message' => 'Amount transferred successfully.',
                    ]);
                }
            } else {
                throw new Exception('API type is invalied');
            }
        } catch (\Exception $e) {
            return response()
                ->json(['status' => 'failed', 'message' => $e->getMessage()])
                ->setStatusCode(500);
        }
    }

    /* Get account type and owener name using owner id  */

    public function accountsdata(Request $request, $id)
    {
        try {
            $owenerId = $id;
            if (
                $request->input('api_type') &&
                $request->input('api_type') == 'accountdetailschekcing'
            ) {
                $accounts = $this->accountsData;
                $account_data = [];

                foreach ($accounts as $key => $account) {
                    if (
                        $account['id'] == $owenerId &&
                        $account['account_status'] == 'Active'
                    ) {
                        $account_data = $account;
                    }
                }

                if ($account_data) {
                    $accountTypes = $this->accountTypes;
                    $account_type = [];
                    foreach ($accountTypes as $key => $accountType) {
                        if (
                            in_array(
                                $account_data['account_type_id'],
                                $accountType
                            )
                        ) {
                            $account_type['type'] = $accountType['type'];
                        }
                    }

                    $subAccountTypes = $this->subAccountTypes;
                    $subAccount_type = [];
                    foreach ($subAccountTypes as $key => $subAccountType) {
                        if (
                            in_array(
                                $account_data['account_sub_type_id'],
                                $subAccountType
                            )
                        ) {
                            if (
                                $subAccountType['id'] ==
                                $account_data['account_sub_type_id']
                            ) {
                                $subAccount_type['account_sub_type'] =
                                    $subAccountType['account_sub_type'];
                            }
                        }
                    }
                    $result = [];
                    $result['accountType'] = !empty($account_type)
                        ? $account_type['type']
                        : '';

                    $result['subAccountType'] = !empty($subAccount_type)
                        ? $subAccount_type['account_sub_type']
                        : '';

                    $result['ownerName'] = $account_data['account_owner_name'];
                    $result['accountStatus'] = $account_data['account_status'];
                    return response()->json([
                        'status' => 'success',
                        'data' => $result,
                        'message' => 'Bank account owner details.',
                    ]);
                } else {
                    throw new Exception('There is no account with this id.');
                }
            } else {
                throw new Exception('API type invalied.');
            }
        } catch (\Exception $e) {
            return response()
                ->json(['status' => 'failed', 'message' => $e->getMessage()])
                ->setStatusCode(500);
        }
    }
}
