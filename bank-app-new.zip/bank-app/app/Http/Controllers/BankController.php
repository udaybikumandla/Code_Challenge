<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Exception;
use Illuminate\Contracts\Validation\Validator;

class BankController extends Controller
{
    public function index(Request $request)
    {       
       
        try {
            if (
                $request->input('api_type') &&
                $request->input('api_type') == 'banklist'
            ) {
                $bankPath = public_path() . '/json/Bank.json';
                $banks = [];
                $banks = json_decode(file_get_contents($bankPath), true);
                if ($banks) {
                    return response()->json([
                        'status' => 'success',
                        'data' => $banks,
                        'message' => 'Bank List',
                    ]);
                } else {
                    throw new Exception('server error');
                }
            } else {
                throw new Exception('API type invalied');
            }
        } catch (\Exception $e) {
            return response()
                ->json(['status' => 'failed', 'message' => $e->getMessage()])
                ->setStatusCode(500);
        }
    }
}
