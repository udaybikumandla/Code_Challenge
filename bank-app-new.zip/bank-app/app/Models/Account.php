<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Database\Eloquent\SoftDeletes;

class Account extends Model
{
    use HasFactory;
    use SoftDeletes;
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */

    protected $fillable = [
        'id',
        'bank_id',
        'account_number',
        'account_type_id',
        'account_sub_type_id',
        'account_owner_name',
        'account_balance',
        'mobile',
        'address',
        'created_at',
        'updated_at',
    ];
    public function accountType($id)
    {
        //  $articles =DB::table('accounts')
        //             ->join('account_types', 'account_types.id', '=', 'accounts.account_type_id')
        //             ->select('account_types.id','account_types.account_type')
        //             ->where('accounts.account_type_id','=', $id)->get();
        //             $queries = DB::getQueryLog();
        // =
        //  DB::connection()->enableQueryLog();
        return $articles = DB::table('account_types')
            ->where('id', $id)
            ->get()
            ->first();
        //$queries = DB::getQueryLog();
        // dd($articles);
    }
    public function AccountUserExitOrNot($name)
    {
        return $accountUserName = Account::where(
            'account_owner_name',
            $name
        )->get();
    }
    public function AccountNumberExitOrNot($id)
    {
        return $accountNumbr = Account::where('account_number', $id)->get();
    }

    public function bankdetails($id)
    {
        return $bankData = DB::table('banks')
            ->where('id', $id)
            ->get()
            ->first();
    }

    public function accountSubType($id)
    {
        return $bankData = DB::table('sub_accounyt_types')
            ->where('id', $id)
            ->get()
            ->first();
    }

    public function AllBankAccountList($id)
    {
        return $bankAccountList = DB::table('accounts')
            ->join('banks', 'banks.id', '=', 'accounts.bank_id')
            ->select('accounts.*')
            ->where('accounts.bank_id', '=', $id)
            ->get();
    }

    public function getAccountDetailsBasedONOwenerID($ownerid, $accountNumber)
    {
        return $accountData = DB::table('accounts')
            ->join('banks', 'banks.id', '=', 'accounts.bank_id')
            ->join(
                'account_types',
                'account_types.id',
                '=',
                'accounts.account_type_id'
            )
            ->join(
                'sub_accounyt_types',
                'sub_accounyt_types.id',
                '=',
                'accounts.account_sub_type_id'
            )
            ->select(
                'accounts.*',
                'banks.*',
                'account_types.account_type',
                'sub_accounyt_types.account_sub_type'
            )
            ->where('accounts.account_number', $accountNumber)
            ->where('accounts.id', $ownerid)
            ->get()
            ->first();
    }
    /* Owner Account deleted */

    public function removeAccount($id)
    {
        return Account::where('id', $id)->delete();
    }

    public function availableBalance($bankId, $ownerID)
    {
        return Account::select('account_balance')
            ->where('bank_id', $bankId)
            ->where('id', $ownerID)
            ->get()
            ->first();
    }
    public function depositMoney($bankId, $ownerID, $amount)
    {
        return Account::where('bank_id', $bankId)
            ->where('id', $ownerID)
            ->update(['account_balance' => $amount]);
    }

    public function AccountOwnerIdExitOrNot($id)
    {
        return $accountUserName = Account::where('id', $id)
            ->where('deleted_at', '=', null)
            ->get();
    }
    public function getAccountData($ownerid)
    {
        return $accountData = DB::table('accounts')
            ->join('banks', 'banks.id', '=', 'accounts.bank_id')
            ->join(
                'account_types',
                'account_types.id',
                '=',
                'accounts.account_type_id'
            )
            ->join(
                'sub_accounyt_types',
                'sub_accounyt_types.id',
                '=',
                'accounts.account_sub_type_id'
            )
            ->select(
                'accounts.*',
                'banks.*',
                'account_types.account_type',
                'sub_accounyt_types.account_sub_type'
            )
            ->where('accounts.id', $ownerid)
            ->get()
            ->first();
    }

    public function withdrawMoney($bankId, $ownerID, $amount, $account_no)
    {
        return Account::where('bank_id', $bankId)
            ->where('id', $ownerID)
            ->where('account_number', $account_no)
            ->update(['account_balance' => $amount]);
    }

    public function transferMoney(
        $frombankId,
        $fromownerID,
        $fromTotalAmount,
        $fromAccountNo,
        $toOwnerid,
        $tobankid,
        $toaAcountNo,
        $toAccountTotal
    ) {
        
         Account::where('bank_id', $frombankId)
            ->where('id', $fromownerID)
            ->where('account_number', $fromAccountNo)
            ->update(['account_balance' => $fromTotalAmount]);
          Account::where('bank_id', $tobankid)
            ->where('id', $toOwnerid)
            ->where('account_number', $toaAcountNo)
            ->update(['account_balance' => $toAccountTotal]);
    }
}
