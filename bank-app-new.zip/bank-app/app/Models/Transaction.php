<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Transaction extends Model
{
    use HasFactory;
    protected $fillable = [
        'id',
        'bank_id',
        'sender_owener_id',
        'recevier_owener_id',
        'transaction_type_id',
        'transaction_mode',
        'transaction_amount',
        'total_amount',
        'created_at',
        'updated_at',
    ];

    public function InsertDataTrnasaction($res)
    {
        return Transaction::create($res);
    }
}
