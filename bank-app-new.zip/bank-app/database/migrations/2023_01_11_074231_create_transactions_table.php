<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTransactionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('transactions', function (Blueprint $table) {
            $table->id();
            $table->integer('bank_id');
            $table->integer('sender_owener_id');
            $table->integer('recevier_owener_id')->nullable();
            $table->integer('transaction_type_id');
            $table->enum('transaction_mode',['CASH', 'NEFT','UPI']);
            $table->decimal('transaction_amount')->default(0,2);
            $table->decimal('total_amount')->default(0,2);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('transactions');
    }
}
