<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAccountsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('accounts', function (Blueprint $table) {
            $table->id();
            $table->string('bank_id');
            $table->string('account_number');
            $table->string('account_type_id');
            $table->string('account_sub_type_id')->nullable();
            $table->string('account_owner_name', 25);
            $table->decimal('account_balance')->default(0,2);
            $table->string('mobile', 12);
            $table->mediumText('address')->nullable();
            $table->string('deleted_at')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('accounts');
    }
}
